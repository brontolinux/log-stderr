package Log::Stderr;

use 5.008000;
use strict;
use warnings;

use Carp ;

use base 'Exporter' ;

our $VERSION = '0.01';

my @LOG_CONSTANTS = qw{
			LOG_NONE   LOG_EMERG LOG_ALERT
			LOG_CRIT   LOG_ERR   LOG_WARNING
			LOG_NOTICE LOG_INFO  LOG_DEBUG
		    } ;

my @LOG_ALIASES   = qw{
			LOG_ERROR  LOG_WARN
		    } ;

my @FUNCTIONS     = qw{ logger } ;

my @TAGS          = qw{all constants aliases} ;

my @SYMBOLS       = ( @LOG_CONSTANTS, @LOG_ALIASES, @FUNCTIONS ) ;

our @EXPORT_OK    = ( @SYMBOLS, @TAGS ) ;

our %EXPORT_TAGS  = (
		     all       => \@SYMBOLS,
		     constants => \@LOG_CONSTANTS,
		     aliases   => \@LOG_ALIASES,
		    ) ;

sub LOG_NONE    { return 0 } ;
sub LOG_EMERG   { return 1 } ;
sub LOG_ALERT   { return 2 } ;
sub LOG_CRIT    { return 3 } ;
sub LOG_ERR     { return 4 } ;
sub LOG_WARNING { return 5 } ;
sub LOG_NOTICE  { return 6 } ;
sub LOG_INFO    { return 7 } ;
sub LOG_DEBUG   { return 8 } ;

# Aliases
*LOG_ERROR = \&LOG_ERR ;
*LOG_WARN  = \&LOG_WARNING ;

# Default DEBUGLEVEL = LOG_NOTICE
our $DEBUGLEVEL = LOG_NOTICE ;


sub logger {
  my ($level,$message) = @_ ;

  return if $level > $DEBUGLEVEL ;

  $message .= qq{\n} if not $message =~ m{\n$} ;
  my $now   = scalar localtime ;

  print STDERR qq{[$now] $message} ;
}


1;
__END__

=head1 NAME

Log::Stderr - Simple logging to Stderr

=head1 SYNOPSIS

To use the logger function and constants

  use Log::Stderr qw{:all} ;
  $Log::Stderr::DEBUGLEVEL = 2 ;
  
  logger(LOG_INFO,"Starting") ;


To just use the logger function:

  use Log::Stderr qw{logger} ;
  $Log::Stderr::DEBUGLEVEL = 4 ;
  
  logger(2,"This message will be printed") ;
  logger(5,"This one will not") ;


=head1 DESCRIPTION

This module defines a convenient way to have a timestamped log output
on STDERR. It also defines some mnemonic constant that you may want to
use.


=head1 SEE ALSO

This module uses constant and Carp.


=head1 AUTHOR

Marco Marongiu, E<lt>bronto@opera.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2010 by Marco Marongiu

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.10.0 or,
at your option, any later version of Perl 5 you may have available.


=cut
